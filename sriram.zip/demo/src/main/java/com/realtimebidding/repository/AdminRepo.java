package com.realtimebidding.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.realtimebidding.entity.Admin;



	
	@Repository
	public interface AdminRepo extends JpaRepository<Admin, Long> {

	
}
