package com.realtimebidding.services;


import com.realtimebidding.entity.Admin;
import com.realtimebidding.entity.Customer;
import com.realtimebidding.exceptions.CustomerException;
import com.realtimebidding.exceptions.UserNotFoundException;



public interface LoginService {
	
	public Customer validateCustomer(Customer customer) throws UserNotFoundException;
	public String signOutAdmin(Admin admin) throws UserNotFoundException;
	public String signOutCustomer(Customer customer) throws UserNotFoundException;
	public Customer addCustomer(Customer customer) throws CustomerException;
}
