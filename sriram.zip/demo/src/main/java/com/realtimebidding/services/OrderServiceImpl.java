package com.realtimebidding.services;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.realtimebidding.entity.Customer;
import com.realtimebidding.entity.Order;
import com.realtimebidding.repository.CustomerRepository;
import com.realtimebidding.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	CustomerRepository cDao;
	
	@Autowired
	OrderRepository oDao;
	
	
	@Override
	public List<Order>viewAllOrders() {
		return oDao.findAll();
	}
		
		
	
	   public Order viewOrder(int custId) {
		
		   return oDao.findById(custId).get();
	   }

}
