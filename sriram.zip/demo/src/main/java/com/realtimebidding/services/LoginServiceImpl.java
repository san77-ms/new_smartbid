package com.realtimebidding.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.realtimebidding.entity.Admin;
import com.realtimebidding.entity.Customer;
import com.realtimebidding.exceptions.CustomerException;
import com.realtimebidding.exceptions.UserNotFoundException;
import com.realtimebidding.repository.AdminRepo;
import com.realtimebidding.repository.CustomerRepository;
import com.realtimebidding.services.LoginService;





@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	CustomerRepository repo;
	
	@Autowired
	AdminRepo adminRepo;
	
	
	public Customer addCustomer(Customer customer) throws CustomerException {
		Customer customerObject;
	
		try {
			
			if(customer==null)
				throw new CustomerException("Customer details missing");
			
			
			customerObject = repo.save(customer);
			
			System.out.println("New customer " + customer.getCustomerId() + " successfully registered...");
		} 
		
		catch (CustomerException e) {
			throw e;
		}
		
		return customerObject;
	}



	
	@Override
	public String signOutAdmin(Admin admin) throws UserNotFoundException {
		// TODO Auto-generated method stub
		return "Admin signed out successfully..." ;
	}

	@Override
	public String signOutCustomer(Customer customer) throws UserNotFoundException {
		// TODO Auto-generated method stub
		return "Customer signed out successfully..." ;
	}



	@Override
	public Customer validateCustomer(Customer customer) throws UserNotFoundException {
		Customer customerObject = null;
		Customer optionalCustomer=new Customer();
		optionalCustomer=repo.findById(customer.getCustomerId()).get();
		
		//Optional<Customer> optionalCustomer=repo.getById(customer.getCustomerId());
		if(optionalCustomer!=null)
			customerObject = optionalCustomer;
		if(optionalCustomer!=null)
		{
			if(optionalCustomer.getPassword().equals(customer.getPassword()))
			{
				return customerObject;
			}
			else
			{
				throw new UserNotFoundException("Incorrect password...");
			}
		}
		else
		{
			throw new UserNotFoundException("Customer Not Found");
		}
	}
}
