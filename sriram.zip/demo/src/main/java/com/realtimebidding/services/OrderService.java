package com.realtimebidding.services;

import java.util.List;

import com.realtimebidding.entity.Order;

public interface OrderService {
	
	   public List<Order> viewAllOrders();
	   public Order viewOrder(int custId);
	   

}
