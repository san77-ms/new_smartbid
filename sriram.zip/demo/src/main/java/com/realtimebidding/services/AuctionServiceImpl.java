package com.realtimebidding.services;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.realtimebidding.entity.Auction;
import com.realtimebidding.repository.AuctionRepository;




@Service
public class AuctionServiceImpl implements AuctionService {
	
	@Autowired
	private AuctionRepository auctionRepository;

	@Override
	public Auction getById(Integer id) throws Exception {
		 return  auctionRepository.findById(id).get();
		
	}

	@Override
	public List<Auction> getAllActive() throws Exception {
		// TODO Auto-generated method stub
		return auctionRepository.findAll();
	}

	@Override
	public Auction addNewAuction(Auction auction) throws Exception {
		return auctionRepository.saveAndFlush(auction);
	}

	@Override
	public Auction updateAuction(Integer id, Auction auction) throws Exception {
		if(auctionRepository.existsById(id))
			return auctionRepository.save(auction);
		throw new RuntimeException("No such Auction exists with Auction id -> "+id);
	}

	@Override
	public void deleteAuction(Integer id) throws Exception {
		 auctionRepository.deleteById(id);
	}

	

}