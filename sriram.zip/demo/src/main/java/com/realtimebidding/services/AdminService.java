package com.realtimebidding.services;

public interface AdminService {

}
