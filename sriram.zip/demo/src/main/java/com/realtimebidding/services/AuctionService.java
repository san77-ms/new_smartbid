package com.realtimebidding.services;

import java.util.List;

import com.realtimebidding.entity.Auction;



public interface AuctionService {
    
	public Auction getById(Integer id)throws Exception;
	
	public List<Auction> getAllActive() throws Exception;
	
	public Auction addNewAuction(Auction auction)throws Exception;
	
	public Auction updateAuction(Integer id,Auction auction)throws Exception;
	
	public void deleteAuction(Integer id)throws Exception; 

}
