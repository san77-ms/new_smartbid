package com.realtimebidding.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.*;
import org.springframework.beans.factory.annotation.Autowired;

import com.realtimebidding.entity.Product;
import com.realtimebidding.exceptions.ProductException;
import com.realtimebidding.repository.ProductRepository;

public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository repo;

	@Override
	public List<Product> viewAllProducts() throws ProductException {

		List<Product> list= repo.findAll();
		
		if(list.size()==0)
			throw new ProductException("No Products Found");
		
		else 
			return list;
	}

	

	@Override
	public Product updateProduct(Product product) throws ProductException {
		if(product.getProductId()==0)
			throw new ProductException("Id is required to update");
		Product container = repo.findById(product.getProductId()).get();
		
		if(container!=null) {
			Product original = container;
			if(!(product.getCategory()==null))
				original.setCategory(product.getCategory());
			if(!(product.getPrice()==0.0))
				original.setPrice(product.getPrice());
			if(!(product.getProductName()==null))
				original.setProductName(product.getProductName());
			if(!(product.getQuantity()==null))
				original.setQuantity(product.getQuantity());
			repo.save(original);		
		}
		
		else 
			throw new ProductException("Product not Found");
		
		return product;
	}

	@Override
	public Product viewProduct(int id) throws ProductException {
		
		Product productObject = null;
		Product container = repo.findById(id).get();
		
		if(container!=null) {
			productObject = container;
		}
		
		if(productObject==null)
			throw new ProductException("Product not Found");
		
		else 
			return productObject;
	}

	@Override
	public List<Product> viewProductByCategory(String category) throws ProductException  {
		List<Product> list= repo.findAll();
		
		List<Product> productsByCategory = list.stream()
				.filter(product->product.getCategory().equals(category))
				.collect(Collectors.toList());
		
		return productsByCategory;
	}

	@Override
	public Product removeProduct(int productId) throws ProductException {

		
		Product productObject = repo.findById(productId).get();
		
		if(productObject==null)
			throw new ProductException("Product not Found");
		
		else 
			repo.deleteById(productId);
		
		return productObject;
	}

}