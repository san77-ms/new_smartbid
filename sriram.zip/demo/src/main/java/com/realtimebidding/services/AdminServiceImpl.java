package com.realtimebidding.services;

public class AdminServiceImpl {

}
