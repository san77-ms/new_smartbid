package com.realtimebidding.services;

import java.util.List;

import com.realtimebidding.entity.Customer;
import com.realtimebidding.entity.Order;
import com.realtimebidding.entity.Product;
import com.realtimebidding.exceptions.CustomerNotFoundException;





public interface CustomerService {
	
	//public Customer addCustomer(Customer customer);

	public Customer viewCustomer(int custid) throws CustomerNotFoundException;

	public List<Customer> listAllCustomers();
	
	public List<Order> getAllOrders(int custId);

	public void addProduct(Product product);
	

}
