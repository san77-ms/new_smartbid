package com.realtimebidding.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.realtimebidding.entity.Customer;
import com.realtimebidding.entity.Order;
import com.realtimebidding.entity.Product;
import com.realtimebidding.exceptions.CustomerNotFoundException;
import com.realtimebidding.repository.CustomerRepository;
import com.realtimebidding.repository.OrderRepository;
import com.realtimebidding.repository.ProductRepository;



	
	@Service
	public abstract class CustomerServiceImpl implements CustomerService {
		@Autowired
		CustomerRepository cDao;

		@Autowired
		OrderRepository oDao;
		
		@Autowired
		ProductRepository pDao;
		
		
		//@Override
	/*	public Customer addCustomer(Customer customer) {
			
			cDao.saveAndFlush(customer);
			return customer;
		}*/
		
		

		
		
				
			
		
		@Override
		public Customer viewCustomer(int custId) throws CustomerNotFoundException {
			return cDao.findById(custId).get();
		}
		
		

		@Override
		public List<Customer> listAllCustomers() {
			return cDao.findAll();
		}

		@Override
		public List<Order> getAllOrders(int custId){ 
			
			return cDao.findById(custId).get().getOrders();
		}
		
		
	  public void addProduct(Product product) {
		
			pDao.saveAndFlush(product);
		}
		
	}




