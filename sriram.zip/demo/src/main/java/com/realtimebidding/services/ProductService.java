package com.realtimebidding.services;

import java.util.List;

import com.realtimebidding.entity.Product;
import com.realtimebidding.exceptions.ProductException;

public interface ProductService {
	
	public List<Product> viewAllProducts() throws ProductException ;
	public Product updateProduct(Product product) throws ProductException ;
	public Product viewProduct(int id) throws ProductException;
	public List<Product> viewProductByCategory(String category) throws ProductException ;
	public Product removeProduct(int productId) throws ProductException;
}