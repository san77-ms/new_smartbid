package com.realtimebidding.entity;

public class BidInformation {

}
