package com.realtimebidding.entity;

import javax.persistence.*;
import java.util.*;

@Entity
public class Auction {
	@Id
	private int auctionId;
	
    public int getAuctionId() {
		return auctionId;
	}

	public void setAuctionId(int auctionId) {
		this.auctionId = auctionId;
	}

	@Column
   	private Date startTime;
	
    @Column
	private Date endTime;
	
    @Column
	private Double startingAmount;
	
	public Auction(int auctionId, Date startTime, Date endTime, Double startingAmount) {
		super();
		this.auctionId = auctionId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.startingAmount = startingAmount;
	}

	

	

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Double getStartingAmount() {
		return startingAmount;
	}

	public void setStartingAmount(Double startingAmount) {
		this.startingAmount = startingAmount;
	}

	@Override
	public String toString() {
		return "Auction [auctionId=" + auctionId + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", startingAmount=" + startingAmount + "]";
	}
	

}
