package com.realtimebidding.entity;

import java.util.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


import org.springframework.data.annotation.Id;



@Entity
public class Customer extends User {
	

	private String custName;
	@OneToMany(cascade = CascadeType.ALL)
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@JoinColumn(name = "custId")
	private int custId;
	private String address;
	
	private String mobileNo;
	private String email;
	
	private String firstName;
	private String lastName;
	
	@OneToOne
	private List<Order> orders;
	
	public Customer() {
               super();
	}

	public Customer(String custName, List<Order> orders) {
		this.custName = custName;
		this.orders = orders;
	}
	
	
   public int getCustomerId() {
	   return custId;
   }
   
	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public List<Order> getOrders() {
		return orders;
	}
	
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	

}








	
	
	





