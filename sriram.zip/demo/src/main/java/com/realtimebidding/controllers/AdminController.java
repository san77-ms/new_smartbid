package com.realtimebidding.controllers;
import com.realtimebidding.repository.*;
import java.util.*;
import java.util.HashMap;
import com.realtimebidding.exceptions.*;
import java.util.List;
import java.util.Map;
import com.realtimebidding.entity.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.realtimebidding.entity.ProductBid;
import com.realtimebidding.entity.SellerManage;
import com.realtimebidding.entity.ProductBid;
import com.realtimebidding.repository.ProductBidRepo;
import com.realtimebidding.repository.SellerRepo;



//@CrossOrigin(origins = "http://localhost:3000")

@RestController
@RequestMapping("/api/v1")
public class AdminController {
	@Autowired	
    ProductBidRepo prepo;
	@Autowired
    ProductRepository prepop;
	@Autowired
	SellerRepo sepo;
	/*@PostMapping("/product/{id}")
	public ProductBidBid createProductBid(@PathVariable(value = "id") Long productId) {
			 
	    List<ProductBidBid> PBid = new ArrayList<>();
	    return prepo.findById(productId);
	    //PBid=prepo.findById(productId);
		//return prepo.save(product);
	}*/
	@PostMapping("/productbid/{id}")
	public  ResponseEntity<ProductBid>  createProductBid(@PathVariable(value = "id") Long productId)
			throws ResourceNotFoundException {
         ProductBid product = prepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + productId));
		ProductBid p = new ProductBid();
		p.setBaseprice(product.getBaseprice());
		p.setId(product.getId());
		p.setDescription(product.getDescription());
		p.setName(product.getName());
		prepo.save(p);
		return ResponseEntity.ok().body(p);
	}
	@GetMapping("/productbid")
	public List<ProductBid> getAllproducts() {
		return prepo.findAll();
	}

	@GetMapping("/productbid/{id}")
	public ResponseEntity<ProductBid> getproductById(@PathVariable(value = "id") Long productId)
			throws ResourceNotFoundException {
		ProductBid product = prepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + productId));
		return ResponseEntity.ok().body(product);
	}

	@PutMapping("/productbid/{id}")
	public ResponseEntity<ProductBid> updateproduct(@PathVariable(value = "id") Long productId,
			 @RequestBody ProductBid productDetails) throws ResourceNotFoundException {
		ProductBid product = prepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + productId));
        product.setBaseprice(productDetails.getBaseprice());
        product.setDescription(productDetails.getDescription());
        product.setName(productDetails.getName());
        
		final ProductBid updatedproduct = prepo.save(product);
		return ResponseEntity.ok(updatedproduct);
	}

	@DeleteMapping("/productbid/{id}")
	public Map<String, Boolean> deleteproduct(@PathVariable(value = "id") Long productId)
			throws ResourceNotFoundException {
		ProductBid product = prepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + productId));

		prepo.delete(product);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}	
	
	//SellerDetails
	
	@GetMapping("/sellermanage")
	public List<SellerManage> getSellers() {
		return sepo.findAll();
	}
	
	@PostMapping("/sellermanage")
	public SellerManage createSeller(@RequestBody SellerManage sellermanage) {
		return sepo.save(sellermanage);}
	
	@PutMapping("/sellermanage/{id}")
	public ResponseEntity<SellerManage> updateproduct(@PathVariable(value = "id") Long sellerId,
			 @RequestBody SellerManage sellerDetails) throws ResourceNotFoundException {
		SellerManage seller = sepo.findById(sellerId)
				.orElseThrow(() -> new ResourceNotFoundException("seller not found for this id :: " + sellerId));
		seller.setRating(sellerDetails.getRating());
		seller.setEmail(sellerDetails.getEmail());
		seller.setName(sellerDetails.getName());
        
		final SellerManage updatedseller = sepo.save(seller);
		return ResponseEntity.ok(updatedseller);
		
}
	@DeleteMapping("/sellermanage/{id}")
	public Map<String, Boolean> deleteseller(@PathVariable(value = "id") Long sellerId)
			throws ResourceNotFoundException {
		SellerManage seller = sepo.findById(sellerId)
				.orElseThrow(() -> new ResourceNotFoundException("seller not found for this id :: " + sellerId));

		sepo.delete(seller);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
		
	}
	
	
	
	
	@PostMapping("/product/{id}")
	public  ResponseEntity<Product>  createProduct(@RequestBody Product prod) {
       
		Product p = new Product();
		p.setProductName(prod.getProductName());
		p.setPrice(prod.getPrice());
		p.setQuantity(prod.getQuantity());
		p.setCategory(prod.getCategory());
		p.setImageUrl(prod.getImageUrl());
		
		prepop.save(p);
		return ResponseEntity.ok().body(p);
	}
	@GetMapping("/product")
	public List<Product> getAllproductsp() {
		return prepop.findAll();
	}



	

	
}
