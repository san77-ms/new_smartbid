package com.realtimebidding.exceptions;



	
	public class ProductException extends Exception{
		
		public ProductException() {}
		
		public ProductException(String msg) {
			super(msg);
		}
		
	}

